
const iva = 1.21; 

const productos = [];

const carrito = [];

const llenarCarrito = [];

const lista = document.getElementById("lista") 

const inputEmail = document.querySelector("#floatingInput")

const inputPassword = document.querySelector("#floatingPassword")

const btnSubmit = document.querySelector("#submit")

const btnVer = document.querySelector("#btnVer")

const btnVolver = document.querySelector("#volverC")

const btnCompra = document.querySelector("#compra")

const URL = `../js/productos.json`

let contenidoJSON = [];



